import React from 'react';
 import './ProductCard.css';
 const ProductCard = ({ product }) => {
     return ( 
     <div className="card">
         <img src={product.image} alt={product.name} />
          <div>
             <h2>{product.name}</h2>
              <p>₹{product.price}</p>
               <button>Buy Now</button>
                </div>
                 </div> 
                 );
                 };

export default ProductCard;

