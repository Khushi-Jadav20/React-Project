import React from 'react';
 import ProductCard from './components/ProductCard';
  import './App.css';
        const products = [
     { name: " Galaxy S24 Ultra", 
      price: 89999,
       image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRIybJVFR9wAC44-qI2RCJmL79Wuz5gxnCgB5DbmgEabjDVs6x5Sh8dMqIhFa8wl6_0orviIYJ4KOwQzsYBpiekaHpG8p50fGpFqZJUWXpdvZds6W8COh1-7S4bt7iwN9E-bevZBIA&usqp=CAc" 
      },
       {
         name: "Galaxy Z Flip3 5G ", 
        price: 43708, 
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiBsRAywPumKhyrOx8Vk8_ZSA0Q9NLNFGvmQ&s" 
      },
       { name: "Galaxy Book4 Pro ",
         price: 116999, 
         image: "https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcQwXCOuXkw2CVbvC6z7X_3SPoxLvegUkD5_B7r4-UcT0Jw07WMhvH29mDSbsxQ49ZHfV0AKGxwCk_sQ1mHA6F4oAs_-Y3bCG_kGh9ovVcx_t0J8g2pYnjO9FLoePJk8sdrt_MZ21_KyqsM&usqp=CAc"
         } ,
         {
          name: "Galaxy Watch 7",
         price: 31999, 
         image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTR-p4lQL4-IsVyho7IbJx_P2c4hVCq8Dvxbg&s"

         },
         {
          name: "Galaxy Tablet A9",
         price: 56999, 
         image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSklKBQJo7WTbv3ap2ZTstX66W-2vuPZsg8ug&s"

         }

        ];


  const App = () => {
   return ( 
   <div className="app"> 
      <h1>Samsung Latest Products</h1>
        <div className="product-list">
         {products.map((item, index) => (
          <ProductCard key={index} product={item} />
    ))}
  </div>
</div>

); };
   export default App;


